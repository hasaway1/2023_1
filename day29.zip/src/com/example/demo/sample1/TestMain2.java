package com.example.demo.sample1;

import lombok.AllArgsConstructor;

@AllArgsConstructor
class Point {
	int x;
	int y;
}

@AllArgsConstructor
class Rect {
	Point topLeft;
	Point bottomRight;
}


class Circle1 {
	Point topLeft;
	Point bottomRight;	
}

class Circle2 {
	Point center;
	int radius;
}


public class TestMain2 {

}
