package com.example.demo.sample1;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
class Member {
	private String username;
	private String password;
	private String email;
	private LocalDate birthday;
	
	public void update(String password, String email) {
		this.password = password;
		this.email = email;
	}
	
	public void changePasword(String password) {
		this.password = password;
	}
}

public class TestMain4 {
	public static void main(String[] args) {
		// 1. 4개의 필드만 추가한 상태 : 생성자 있음???
		//    생성자가 없는 경우 자바가 생성자를 추가한다 -> 기본생성자
		
		// 2. @AllArgsConstructor를 추가 -> 기본생성자 제거
		
		// 3. @NoArgsConstructor로 기본생성자 추가
	}
	
}



