package com.example.demo.sample1;

import lombok.AllArgsConstructor;

// 여러개의 정보가 모여서 단위를 구성하는 경우
// 이름은 홍길동, 나이는 20, 주소는 율산국

@AllArgsConstructor
class Saram {
	String irum;
	int nai;
	String address;
}

public class TestMain1 {
	public static void main(String[] args) {
		String irum = "홍길동";
		int nai = 20;
		String address = "율산국";
		int salary = 2000000;
		
		// JS의 객체
		// {irum:irum, nai:nai, address:address} -> {irum, nai, address}
		// 출력하면 {irum:"홍길동", nai:20, address:"율산국"}
		
		Saram saram = new Saram(irum, nai, address);
	}
}


