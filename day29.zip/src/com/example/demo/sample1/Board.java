package com.example.demo.sample1;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Board {
	// 키 : 구별하기 위한 필드
	// 사람 : 주민번호, 아이디, 핸드폰번호, 이메일, 건강보험번호.....
	int bno;
	String title;
	String content;
	String writer;
	LocalDate writeday;
	int readcnt;
	int goodcnt;
	int badcnt;
	public void increaseReadnt() { this.readcnt++; }
	public void good(boolean isCancel) {
		if(isCancel)
			this.goodcnt--;
		else
			this.goodcnt++; 
	}
	public void bad() { this.badcnt++; }
	public void update(String title, String content) {
		this.title = title;
		this.content = content;
	}
}









