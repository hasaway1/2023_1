package com.example.demo.sample1;

import lombok.AllArgsConstructor;

// 1. 이메일, 비밀번호, 주소로 구성된 Member클래스를 작성하시오
// 2. Member 클래스를 이용해서 우편물을 보낼 수 있어야 한다

class Member1 {
	String email;
	String password;
	String address;  
	// 우편번호 11125 서울시 영등포구 여의도동 한성빌딩 103-1202호 ICIA교육원 
}

@AllArgsConstructor
class Address {
	String zipcode;
	String address1;
	String address2;
	String dong;
}

class Member2 {
	String email;
	String password;
	// 의존
	Address address;
}


public class TestMain3 {

}
