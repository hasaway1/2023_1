package com.example.demo.sample1;


// 객체지향 구성요소	    -> 객체지향 설계원칙(SOLID)
//					     1. 단일책임원칙(SRP) : 클래스는 한가지 관심만 담당한다
// 1. 캡슐화	
// 2. 정보은닉 : private이 기본.
// 3. 상속
//		부모는 추상적인 카테고리, 자식은 구체적인 실체
//		부모는 자식들이 살아가는 방법을 정의한다
// 4. 다형성 : 코드는 상황에 따라 대처할 수 있어야 한다 - 오버로딩
class Calc {
	public int sum(int a, int b) {
		return a+b;
	}
	public double sum(double a, double b) {
		return a+b;
	}
}

public class TestMain5 {
	public static void main(String[] args) {
		Calc calc = new Calc();
		calc.sum(3, 4);
		calc.sum(1.2, 3.4);
	}
}



