package com.example.demo.sample2;

import java.util.ArrayList;
import java.util.List;

// TodoDao는 객체를 여러개 만들 필요가 있다??? staic
public class TodoDao {
	private TodoDao() {
	}
	// static은 static끼리만 접근 가능
	private static List<Todo> todos = new ArrayList<>();
	
	public static void create(Todo todo) {
		todos.add(todo);
	}
}

// 디자인 패턴
// Singleton 패턴 : 객체가 한개만 만들어지는 패턴
//				   기능면에서 static 메소드와 마찬가지
//				   객체를 만들지 않는 static 메소드보다는 좀 더 자유롭다

