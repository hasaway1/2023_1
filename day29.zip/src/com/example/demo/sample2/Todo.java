package com.example.demo.sample2;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

// 클래스는 보통 두가지 종류가 있다
// 값을 저장하는 클래스 : entity
// 엔티티를 처리하는 클래스 : dao -> 싱글톤

@Getter
@AllArgsConstructor
@NoArgsConstructor			
@Builder
public class Todo {
	// key
	private int no;
	private String job;
	private LocalDate writeday = LocalDate.now();
	private boolean isComplete = false;
	
	public void changeJob(String job) {
		this.job = job;
	}
	
	public void toggleComplete() {
		this.isComplete=!this.isComplete;
	}
}







