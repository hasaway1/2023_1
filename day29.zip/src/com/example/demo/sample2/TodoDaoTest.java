package com.example.demo.sample2;

import org.junit.jupiter.api.Test;

public class TodoDaoTest {
	@Test
	public void test1() {
		// create가 일반 메소드라면 객체 생성이 필요하다
		// 그런데 처리 클래스에 new를 허용하면 당연히 여러개 만들어질 수 있다
		TodoDao dao = new TodoDao();
		dao.create(null);
	}
	
	@Test
	public void test2() {
		// static으로 가면 객체없이 작업이 가능
		TodoDao.create(null);
	}
}
