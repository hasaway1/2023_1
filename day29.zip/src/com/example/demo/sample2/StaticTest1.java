package com.example.demo.sample2;

import lombok.Getter;

// Sample 클래스의 객체가 몇개나 생성되는 지 알고 싶다
class Sample {
	// 필드는 자동으로 초기화 -> 0
	static int count;
	public Sample() {
		count++;
	}
}
public class StaticTest1 {
	public static void main(String[] args) {
		for(int i=0; i<10; i++) {
			//System.out.println(new Sample().count);
			new Sample();
			System.out.println(Sample.count);
		}
	}
}

// static는 공유 데이터다 -> new하지 않고 사용할 수 있다(new하기 전에 이미 존재한다,)