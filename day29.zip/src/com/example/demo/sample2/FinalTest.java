package com.example.demo.sample2;

// final : 변경 금지
class Sample2 {
	int a = 10;		
	static int b = 20;
	final int c = 30;
	final static int d = 40;
}
public class FinalTest {
	public static void main(String[] args) {
		// a는 객체마다 있다
		// b는 모든 객체가 공유하며 변경 가능
		// c는 객체마다 있고 변경 불가(객체마다 가지는 상수) -> 고정금리 대출 이자율
		// d는 모든 객체가 공유하는 상수
		new Sample2();
		new Sample2();
		new Sample2();
	}
}
