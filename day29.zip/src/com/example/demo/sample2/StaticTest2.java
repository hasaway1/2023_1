package com.example.demo.sample2;

public class StaticTest2 {
	public static void main(String[] args) {
		// main의 역할 : 프로그램의 시작(Primary Entry Point)
		// 만약 main이 static이 아니라면
		// 		main을 실행하려면 StaticTest2의 객체가 필요하다
		//			new StaticTest2().main();
		// 그런데 StaticTest2의 객체를 만들려면(라인8을 실행하려면) main이 시작되어야 한다
		
		
		// new로 생성한 객체는 달라야 한다
		System.out.println(Math.PI);
		System.out.println(Math.round(3.17));
		
	}
}
